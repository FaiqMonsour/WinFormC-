﻿using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace StudentRegistrationForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Adding options to ComboBox when the form loads
            cmbCountry.Items.AddRange(new string[] { "Egypt", "KSA", "UAE", "USA", "Yemen" });
            cmbCountry.SelectedIndex = 0; // Set a default selection
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Collecting input data
            string name = txtName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string country = cmbCountry.SelectedItem.ToString();
            string gender = GetSelectedGender();
            string favoriteColor = btnChooseColor.Text;

            // Check if all required fields are filled
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(gender) || string.IsNullOrEmpty(favoriteColor))
            {
                MessageBox.Show("Please fill in all required fields!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate email format
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Invalid email format! Please enter a valid email address.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Display entered data
            lblResult.Text = $"Name: {name}\nEmail: {email}\nFavorite Color: {favoriteColor}\nGender: {gender}\nCountry: {country}\nBirthdate: {dtpBirthdate.Text}";
        }

        private void btnChooseColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                btnChooseColor.Text = colorDialog1.Color.Name;
                btnChooseColor.ForeColor = colorDialog1.Color;
            }
        }

        private string GetSelectedGender()
        {
            if (rdMale.Checked)
                return "Male";
            else if (rdFemale.Checked)
                return "Female";
            else
                return string.Empty; 
        }

        private bool IsValidEmail(string email)
        {
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, emailPattern);
        }
    }
}